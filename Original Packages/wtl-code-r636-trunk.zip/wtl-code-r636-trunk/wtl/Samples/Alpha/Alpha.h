// Alpha.h
