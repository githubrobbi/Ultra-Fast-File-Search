// Wizard97Test.h
